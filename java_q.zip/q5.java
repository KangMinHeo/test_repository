import java.util.Scanner;

public class q5 {
    /*
        숫자를 입력받고

        해당 숫자가 10 이상이면 해당 숫자부터 다음 10개의 숫자를 출력
        숫자를 입력하세요
        12
        12      13      14      15      16      17      18      19      20      21

        해당 숫자가 10보다 작으면 해당 숫자부터 0까지 숫자를 출력
        숫자를 입력하세요
        5
        5       4       3       2       1       0
    */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("숫자를 입력하세요");
        int num = sc.nextInt(); sc.nextLine();

        if(){
            for(){
                System.out.print(i + "\t");
            }
        } else {
            for(){
                System.out.print(i + "\t");
            }
        }
    }
}
