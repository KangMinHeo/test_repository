public class q2 {
    /*
    *  1에서 10의 숫자 중에서 6이상은 제곱으로 표기해라 
    *  결과 => 1       2       3       4       5       36      49      64      81      100
    */
    public static void main(String[] args) {
        for(){
            if(){
                
            } else {
                
            }
        }
    }
}
