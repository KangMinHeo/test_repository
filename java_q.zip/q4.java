public class q4 {
    /*
        if안에 알맞은 조건식을 넣어서 값이 출력되게 해라
    */
    public static void main(String[] args) {
        String str1 = "홍길동";
        String str2 = "가나다";

        if(){
            System.out.println("출력");
        }
    }
}
