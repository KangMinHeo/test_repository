// 결과
// 0       1       2       3       4       5       6       7       8       9
public class q1 {
    public static void main(String[] args) {
        for(){
            System.out.print(i + "\t");
        }
    }
}